<?php

namespace App\Http\Controllers;

use Webpatser\Uuid\Uuid;
use Illuminate\Http\Request;
use App\Models\file;

class FileUploadController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $files = file::all();
        return view('fileupload.index', compact('files'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        try {
            $file = $request->all();
            $file['uuid'] = (string) Uuid::generate();
            if ($request->hasFile('file')) {
                $file['title'] = $request->file->getClientOriginalName();
                $request->file->move(storage_path('app/file'), $file['uuid'] . '.' . $request->file->extension());
            }
            file::create($file);
            return response()->json(['data' => 'success'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 423);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        //
    }

    /**
     * Download file by UUID
     *
     * @param  int  $uuid
     * @return \Illuminate\Http\Response
     */
    public function download($uuid) {
        $file = file::where('uuid', $uuid)->firstOrFail();
        $extension= last(explode('.', $file['title']));
        $pathToFile = storage_path('app/file/' . $file->uuid.'.'.$extension);
        return response()->download($pathToFile);
    }

}
